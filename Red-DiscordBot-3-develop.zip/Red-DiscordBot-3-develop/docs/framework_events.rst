.. framework events list

=============
Custom Events
=============

RPC Server
^^^^^^^^^^

.. py:method:: Red.on_shutdown()

    Dispatched when the bot begins it's shutdown procedures.
