# New feature addition

<!--
THIS TEMPLATE IS CURRENTLY UNUSED DUE TO GITHUB LIMITATIONS!
To be used for PRs which add a new feature
Examples of this include new APIs, new core cogs, etc.
-->

#### What type of feature is this?

<!-- To check a box, replace the space between the [] with a x -->

- [ ] New core cog
- [ ] New API
- [ ] Other

#### Describe the feature

<!--
If you are adding a cog, describe its commands in detail (functionality, usage restrictions, etc).
If the new feature introduces new requirements, please try to explain why they are necessary.
-->
